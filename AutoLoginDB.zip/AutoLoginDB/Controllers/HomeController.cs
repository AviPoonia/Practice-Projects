﻿using AutoLoginDB.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.Web.Mvc;

namespace AutoLoginDB.Controllers
{
    public class HomeController : Controller
    {
        private string GetRedirectUrl(string returnUrl)
        {
            if (string.IsNullOrEmpty(returnUrl) || !Url.IsLocalUrl(returnUrl) || returnUrl=="/")
            {
                return Url.Action("index", "home");
            }

            return returnUrl;
        }
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        public ActionResult Login(string returnURL)
        {
            var UserID = ClaimsPrincipal.Current.Identity.Name;
            int x = CommonOperations.CheckLogin(Convert.ToInt32( !string.IsNullOrWhiteSpace(UserID)?UserID:"0"));
            if (x == 0)
            {
                ViewBag.ReturnUrl = returnURL;
                return View();
            }
            else
            {
                return Redirect(GetRedirectUrl(returnURL));
            }

        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult Login(LoginViewModel model)
        {
            int result = 0;
            try
            {

                string connectionString = "Data Source='ana-test-bx-006, 1435';Initial Catalog=Test;Persist Security Info=True;User ID=sa;Password=Analec123";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("spLogin", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@UserName", model.UserName);
                    cmd.Parameters.AddWithValue("@Password", model.Password);
                    cmd.Parameters.AddWithValue("@RememberMe", model.RememberMe);

                    con.Open();
                    result = Convert.ToInt32(cmd.ExecuteScalar());
                    con.Close();

                    if (result > 0)
                    {
                        var identity = new ClaimsIdentity(new[] {
                        new Claim(ClaimTypes.Name, "1"),
                        new Claim(ClaimTypes.Role, "Admin")
                        }, "ApplicationCookie");

                        var ctx = Request.GetOwinContext();
                        var authManager = ctx.Authentication;

                        authManager.SignIn(identity);
                        return Redirect(GetRedirectUrl(model.ReturnUrl));
                    }
                    else
                    {
                        ViewBag.msg = "Login Failed";
                    }
                }
            }
            catch (Exception ex)
            {
                var LoginError = ex.InnerException.ToString();
            }
            return View();

        }
        public ActionResult About()
        {
            return View();
        }

        [Authorize(Roles = "Admin")]
        public ActionResult AdminPage()
        {
            return View();
        }

        public ActionResult LogOut()
        {
            var ctx = Request.GetOwinContext();
            var authManager = ctx.Authentication;

            authManager.SignOut("ApplicationCookie");
            CommonOperations.LogOut(1);

            return RedirectToAction("Login", "home");
        }
    }
}