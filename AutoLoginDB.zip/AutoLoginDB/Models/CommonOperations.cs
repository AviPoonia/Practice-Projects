﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AutoLoginDB.Models
{
    public static class CommonOperations
    {
        public static int CheckLogin(int UserID)
        {
            int result = 0;
            try
            {
                string connectionString = "Data Source='ana-test-bx-006, 1435';Initial Catalog=Test;Persist Security Info=True;User ID=sa;Password=Analec123";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("checkLogin", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };

                    cmd.Parameters.AddWithValue("@UserID", UserID);

                    con.Open();
                    result = Convert.ToInt32(cmd.ExecuteScalar());
                    con.Close();

                    return result;

                }
            }
            catch (Exception ex)
            {
                var LoginError = ex.InnerException.ToString();
                return result;
            }
        }


        public static int LogOut(int UserID)
        {
            int result = 0;
            try
            {
                string connectionString = "Data Source='ana-test-bx-006, 1435';Initial Catalog=Test;Persist Security Info=True;User ID=sa;Password=Analec123";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("UserLogout", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };

                    cmd.Parameters.AddWithValue("@UserID", UserID);

                    con.Open();
                    result = Convert.ToInt32(cmd.ExecuteScalar());
                    con.Close();

                    return result;

                }
            }
            catch (Exception ex)
            {
                var LoginError = ex.InnerException.ToString();
                return result;
            }
        }

    }
}