﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using CommandType = System.Data.CommandType;
using System.Drawing;
using System.IO;
using System.Net;
using ServerPaging.Models;

namespace ServerPaging.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(int page = 1)
        {
            //Defining the PageSize
            int PageSize = 10;
            //Creating the ViewModel's Object
            GridViewModel obj = new GridViewModel();
            DataSet ds = new DataSet();
            //List of the Grid data
            List<GridData> lstPerson = new List<GridData>();
            SqlConnection con = null;
            SqlDataAdapter query_adapter = new SqlDataAdapter();
            try
            {

                con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
                SqlCommand cmd = new SqlCommand("TestGetEmp6", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@SearchString", "");
                cmd.Parameters.AddWithValue("@PageNumber", page);
                cmd.Parameters.AddWithValue("@PagingSize", PageSize);

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    GridData cobj = new GridData();
                    cobj.company_id = Convert.ToInt32(ds.Tables[0].Rows[i]["company_id"].ToString());
                    cobj.organisation_type = ds.Tables[0].Rows[i]["organisation_type"].ToString();
                    cobj.company_name = ds.Tables[0].Rows[i]["company_name"].ToString();
                    cobj.organisation_type = ds.Tables[0].Rows[i]["organisation_type"].ToString();
                    cobj.company_fax = ds.Tables[0].Rows[i]["company_fax"].ToString();
                    cobj.company_web_address = ds.Tables[0].Rows[i]["company_web_address"].ToString();
                    cobj.company_email_address = ds.Tables[0].Rows[i]["company_email_address"].ToString();
                    cobj.company_telephone_number_1 = ds.Tables[0].Rows[i]["company_telephone_number_1"].ToString();
                    cobj.company_telephone_number_2 = ds.Tables[0].Rows[i]["company_telephone_number_2"].ToString();
                    cobj.company_email_address = ds.Tables[0].Rows[i]["company_email_address"].ToString();

                    lstPerson.Add(cobj);
                }
                //Passing the TotalRecordsCount, Current Page and Page Size in the constructore of the Pager Class
                var pager = new Pager((ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0) ? Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]) : 0, page, PageSize);
                obj.ListGrid = lstPerson;
                obj.pager = pager;
            }
            catch (Exception ex)
            {
                var GridDataError = ex.InnerException.ToString();
            }
            finally
            {
                con.Close();
            }
            return View(obj);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

    }
}