﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CustomErrorHandling.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            throw new Exception("Something went wrong");
        }
        public ActionResult Index2()
        {
            throw new Exception("Something went wrong again");
        }
        public ActionResult Index3()
        {
            throw new Exception("Something went wrong once more");
        }

        

    }
}